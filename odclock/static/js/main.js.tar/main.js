
$(document).on('ready', function() {
	$('#id_especialidad').on('change', function() { 
		var val = $('#id_especialidad option:selected').html();

		$.ajax({
			async:true,
			url:'ajaxespecialidad',
			data:'a='+val+'&valor&csrfmiddlewaretoken=' + getCookie('csrftoken'),
			type:'post',
			dataType: 'html',
			beforeSend: function () {
				$('#id_dentista').empty()
				
			},
			success: function(respuesta) {
				hora(respuesta);
			},
			timeout: 8000,
			error: function () {
				alert('Ha ocurrido un error, por favor inténtelo nuevamente.');
			}
		})
	});
});

function hora(jdata){
	$('#id_dentista').append('<option value ="0">elija...</option>');
	var coso = JSON.parse( jdata );
    for (var i = 0; i < coso.length; i++){
		$('#id_dentista').append('<option value ="'+i+'">'+coso[i]+'</option>');
	};
}

///**********************************************

$(document).on('ready', function() {
	$('#id_dentista').on('change', function() { 
		var val = $('#id_dentista option:selected').html();

		$.ajax({
			async:true,
			url:'ajaxespecialidad',
			data:'a='+val+'&valor&csrfmiddlewaretoken=' + getCookie('csrftoken'),
			type:'post',
			dataType: 'html',
			beforeSend: function () {
				$('#id_dentista').empty()
				
			},
			success: function(respuesta) {
				calendario(respuesta);
			},
			timeout: 8000,
			error: function () {
				alert('Ha ocurrido un error, por favor inténtelo nuevamente.');
			}
		})
	});
});

var dias = [
	'lunes'
	, 'martes'
	, 'miércoles'
	, 'jueves'
	, 'viernes'
];

var horarios = [
	'08:00'
	, '08:30'
	, '09:00'
	, '09:30'
	, '10:00'
];

function calendario(dato){
	
	var numero_dia = 4;
	var numero_mes = 6;
	var mes = 8;

	var largo_semana = dias.length;

	var $grilla = $('#grilla');
	var $cabecera = $('#cabecera');

	var primer_dia = numero_mes - numero_dia + 1;

	(function (){
		var $row = $('<tr></tr>');
		$row.append('<th>Bloque</th>');
		$.each(dias, function(idx, dia) {
			console.log(dia);
			var $col = $('<th> ' + dia + ' ' + (primer_dia + idx) + '</th>');
			$row.append($col);
		})

		$cabecera.append($row)
	})();

	$.each(horarios, function (idx, horario) {
		console.log(horario)
		var $row = $('<tr></tr>');
		var $horario = $('<td> ' + horario + '</td>')
		$row.append($horario);

		$.each(dias, function(idx_dia, dia){
			var $bloque = $('<td id="' + mes + '-' + (idx_dia + primer_dia) + '-' + idx + '"></td>');
			$row.append($bloque);
		});		

		$grilla.append($row);
	});
}